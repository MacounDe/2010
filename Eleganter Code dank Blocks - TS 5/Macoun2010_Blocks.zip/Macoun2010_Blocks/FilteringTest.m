//
//  FilteringTest.m
//  Macoun2010_Blocks
//
//  Created by Frank Illenberger on 29.09.10.
//  Copyright 2010 ProjectWizards. All rights reserved.
//

#import "FilteringTest.h"
#import "Nerd.h"
#import "MCNTools.h"


@implementation FilteringTest

- (void)run
{
    NSUInteger count = 1E+6;
    NSMutableArray* nerds = [[NSMutableArray alloc] initWithCapacity:count];
    
    [MCNTools timeAction:@"Creation" block:^
     {
         for(NSUInteger index=0; index<count; index++) 
         {
             NSString* name = [NSString stringWithFormat:@"Nerd #%d", count-index];
             [nerds addObject:[[Nerd alloc] initWithName:name]];
         }
     }];
    
    NSPredicate* blockPredicate = [NSPredicate predicateWithBlock:^BOOL(id obj, NSDictionary* bindings) {
        Nerd* iNerd = obj;
        return iNerd.name.length == 6;
    }];
    
    NSPredicate* keyValuePredicate = [NSPredicate predicateWithFormat:@"name.length = 6"];
    
    [NSThread sleepForTimeInterval:0.5];
    
    [MCNTools timeAction:@"Key-value predicate" block:^
     {
         [nerds filteredArrayUsingPredicate:keyValuePredicate];
     }];
    
    [NSThread sleepForTimeInterval:0.5];
    
    [MCNTools timeAction:@"Block predicate" block:^
     {
         [nerds filteredArrayUsingPredicate:blockPredicate];
     }];
    
}

@end
