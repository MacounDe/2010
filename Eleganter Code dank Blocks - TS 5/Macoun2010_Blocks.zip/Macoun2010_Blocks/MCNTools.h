//
//  MCNTools.h
//  Macoun2010_Blocks
//
//  Created by Frank Illenberger on 30.09.10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>

typedef void (^MCNActionBlock)();

@interface MCNTools : NSObject

+ (void)timeAction:(NSString*)actionName
             block:(MCNActionBlock)actionBlock;
@end
