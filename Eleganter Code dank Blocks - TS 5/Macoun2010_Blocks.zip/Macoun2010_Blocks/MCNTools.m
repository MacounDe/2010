//
//  MCNTools.m
//  Macoun2010_Blocks
//
//  Created by Frank Illenberger on 30.09.10.
//  Copyright 2010 __MyCompanyName__. All rights reserved.
//

#import "MCNTools.h"

@implementation MCNTools

+ (void)timeAction:(NSString*)actionName
             block:(MCNActionBlock)block
{
    NSParameterAssert(actionName);
    NSParameterAssert(block);
    NSDate* startDate = [NSDate date];
    
    block();
    
    NSTimeInterval duration = -startDate.timeIntervalSinceNow;
    NSLog(@"%@ took %gs", actionName, duration);
}
@end
