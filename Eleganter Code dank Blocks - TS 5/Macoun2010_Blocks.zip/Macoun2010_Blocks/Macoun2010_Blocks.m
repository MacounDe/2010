#import "SortingTest.h"
#import "FilteringTest.h"

int main (int argc, const char * argv[])
{
    __unused SortingTest*   sortingTest   = [[SortingTest alloc]   init];
    __unused FilteringTest* filteringTest = [[FilteringTest alloc] init];
    
    //[sortingTest run];
    [filteringTest run];
    return 0;
}
