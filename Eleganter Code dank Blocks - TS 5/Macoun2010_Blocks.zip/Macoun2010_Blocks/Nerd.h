//
//  Nerd.h
//  SortTest
//
//  Created by Frank Illenberger on 29.09.10.
//  Copyright 2010 ProjectWizards. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface Nerd : NSObject

@property (readonly) NSString* name;

- (id)initWithName:(NSString*)name;

@end

