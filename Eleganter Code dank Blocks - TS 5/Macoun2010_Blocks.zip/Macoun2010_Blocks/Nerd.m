//
//  Nerd.m
//  SortTest
//
//  Created by Frank Illenberger on 29.09.10.
//  Copyright 2010 ProjectWizards. All rights reserved.
//

#import "Nerd.h"


@implementation Nerd

@synthesize name = name_;

- (id)initWithName:(NSString*)name 
{
    if((self = [self init]))
    {
        name_ = [name copy];
    }
    return self;
} 

@end

