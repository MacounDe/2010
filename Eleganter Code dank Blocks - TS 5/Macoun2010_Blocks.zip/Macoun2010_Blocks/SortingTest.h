//
//  SortingTest.h
//  Macoun2010_Blocks
//
//  Created by Frank Illenberger on 29.09.10.
//  Copyright 2010 ProjectWizards. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface SortingTest : NSObject
- (void)run;
@end
