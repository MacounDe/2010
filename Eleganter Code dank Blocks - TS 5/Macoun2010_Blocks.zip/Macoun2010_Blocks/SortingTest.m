//
//  SortingTest.m
//  Macoun2010_Blocks
//
//  Created by Frank Illenberger on 29.09.10.
//  Copyright 2010 ProjectWizards. All rights reserved.
//

#import "SortingTest.h"
#import "Nerd.h"
#import "MCNTools.h"

@implementation SortingTest

- (void)run
{
    NSUInteger count = 1E+6;
    NSMutableArray* nerds = [[NSMutableArray alloc] initWithCapacity:count];
    
    [MCNTools timeAction:@"Creation" block:^
     {
         for(NSUInteger index=0; index<count; index++) {
             NSString* name = [NSString stringWithFormat:@"Nerd #%d", count-index];
             [nerds addObject:[[Nerd alloc] initWithName:name]];
         }
     }];
    
    [NSThread sleepForTimeInterval:0.5];
    
    [MCNTools timeAction:@"Key-value sorting" block:^
     {
         NSSortDescriptor* descriptor = [[NSSortDescriptor alloc] initWithKey:@"name.length"
																	ascending:YES];
         [nerds sortedArrayUsingDescriptors:[NSArray arrayWithObject:descriptor]];
     }];
    
    [NSThread sleepForTimeInterval:0.5];
    
    [MCNTools timeAction:@"Block sorting" block:^
     {
         [nerds sortedArrayUsingComparator:^NSComparisonResult(id obj1, id obj2) {
             NSUInteger len1 = ((Nerd*)obj1).name.length;
             NSUInteger len2 = ((Nerd*)obj2).name.length;
             return len1 < len2 ? NSOrderedAscending : 
             len1 > len2 ? NSOrderedDescending : NSOrderedSame;
         }];
     }];
    
}

@end
