//
//  Benchmark.h
//  OpenCLBenchmark
//
//  Created by Eberhard Rensch on 27.09.10.
//  Copyright 2010 Pleasant Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import <OpenCL/OpenCL.h>


@interface Benchmark : NSObject {
	double openCLResultTime;
	double skalarResultTime;
	BOOL useGPU;
	NSUInteger iterations;
	
	cl_device_id device_id;             // compute device id 
	cl_context context;                 // compute context
	cl_command_queue commands;          // compute command queue
	cl_program program;                 // compute program
}

@property (readonly) double openCLResultTime; 
@property (readonly) double skalarResultTime; 
@property (assign) BOOL  useGPU;
@property (assign) NSUInteger iterations;

- (void)createOpenCLContext;
- (void)destroyOpenCLContext;
- (void)doBenchmarkCL;
- (void)doBenchmarkSkalar;
@end
