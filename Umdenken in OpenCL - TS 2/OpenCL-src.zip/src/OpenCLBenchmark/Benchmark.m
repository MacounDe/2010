//
//  Benchmark.m
//  OpenCLBenchmark
//
//  Created by Eberhard Rensch on 27.09.10.
//  Copyright 2010 Pleasant Software. All rights reserved.
//

#import "Benchmark.h"

@implementation Benchmark
@synthesize useGPU, iterations, openCLResultTime, skalarResultTime;

- (void)createOpenCLContext
{
	int err;                            // error code returned from api calls

	// Connect to a compute device
	//
	err = clGetDeviceIDs(NULL, useGPU ? CL_DEVICE_TYPE_GPU : CL_DEVICE_TYPE_CPU, 1, &device_id, NULL);
	if (err != CL_SUCCESS)
	{
		printf("Error: Failed to create a device group!\n");
		exit(1);
	}
	
	// Create a compute context 
	//
	context = clCreateContext(0, 1, &device_id, NULL, NULL, &err);
	if (!context)
	{
		printf("Error: Failed to create a compute context!\n");
		exit(1);
	}
	
	// Create a command commands
	//
	commands = clCreateCommandQueue(context, device_id, 0, &err);
	if (!commands)
	{
		printf("Error: Failed to create a command commands!\n");
		exit(1);
	}
	
	
	NSString* kernelSourcePath = [[NSBundle mainBundle] pathForResource:@"openCLKernels" ofType:@"cl"];
	if (!kernelSourcePath)
	{
		printf("Error: Failed to load program source!\n");
		exit(1);
	}
	
	NSString* kernelSource = [NSString stringWithContentsOfFile:kernelSourcePath encoding:NSUTF8StringEncoding error:nil];
	if (!kernelSource)
	{
		printf("Error: Failed to load program source!\n");
		exit(1);
	}	
	
	const char* kernelSourceAsUTF8 = [kernelSource UTF8String];
	
	// Create the compute program from the source buffer
	//
	program = clCreateProgramWithSource(context, 1, (const char **) &kernelSourceAsUTF8, NULL, &err);
	if (!program)
	{
		printf("Error: Failed to create compute program!\n");
		exit(1);
	}
	
	// Build the program executable
	//
	err = clBuildProgram(program, 0, NULL, NULL, NULL, NULL);
	if (err != CL_SUCCESS)
	{
		size_t len;
		char buffer[2048];
		
		printf("Error: Failed to build program executable!\n");
		clGetProgramBuildInfo(program, device_id, CL_PROGRAM_BUILD_LOG, sizeof(buffer), buffer, &len);
		printf("%s\n", buffer);
		exit(1);
	}
}

- (void)destroyOpenCLContext;
{
	clReleaseProgram(program);
	clReleaseCommandQueue(commands);
	clReleaseContext(context);
}

- (void)doBenchmarkCL
{
}

- (void)doBenchmarkSkalar
{
}

@end
