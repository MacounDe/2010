//
//  BenchmarkEindimensional.h
//  OpenCLBenchmark
//
//  Created by Eberhard Rensch on 27.09.10.
//  Copyright 2010 Pleasant Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "Benchmark.h"

@interface BenchmarkEindimensional : Benchmark
{
	cl_uint count;
	cl_float* daten;
	cl_float* ergebnisseCL;
	cl_float* ergebnisseSkalar;
}

- (id) initWithDatasize:(NSUInteger)datasize;

@end
