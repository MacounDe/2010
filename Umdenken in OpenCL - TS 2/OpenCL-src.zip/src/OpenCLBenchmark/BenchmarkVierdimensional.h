//
//  BenchmarkVierdimensional.h
//  OpenCLBenchmark
//
//  Created by Eberhard Rensch on 27.09.10.
//  Copyright 2010 Pleasant Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>
#import "Benchmark.h"

@interface BenchmarkVierdimensional : Benchmark
{
	cl_uint count;
	cl_float4* daten;
	cl_float4* ergebnisseCL;
	cl_float4* ergebnisseSkalar;
}

- (id) initWithDatasize:(NSUInteger)datasize;

@end
