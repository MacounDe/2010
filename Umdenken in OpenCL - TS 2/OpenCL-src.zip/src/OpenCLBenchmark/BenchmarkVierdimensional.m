//
//  BenchmarkVierdimensional.m
//  OpenCLBenchmark
//
//  Created by Eberhard Rensch on 27.09.10.
//  Copyright 2010 Pleasant Software. All rights reserved.
//

#import "BenchmarkVierdimensional.h"
#include <time.h> 
#include "skalarBerechnung.h"

@implementation BenchmarkVierdimensional

- (id) initWithDatasize:(NSUInteger)datasize
{
	self = [super init];
	if (self != nil) {
		count=(cl_uint)datasize;
		daten = malloc(sizeof(cl_float4)*count);
		ergebnisseCL = malloc(sizeof(cl_float4)*count);
		ergebnisseSkalar = malloc(sizeof(cl_float4)*count);
		
		// Daten mit Zufallswerten belegen
		for(NSUInteger i = 0; i < count; i++)
		{
			for(NSUInteger d = 0; d<4; d++)
				daten[i][d] = (cl_float)rand() / (cl_float)RAND_MAX;
		}
	}
	return self;
}

- (void) dealloc
{
	free(daten);
	free(ergebnisseCL);
	free(ergebnisseSkalar);
	
	[super dealloc];
}

- (void)doBenchmarkSkalar
{
	clock_t start, end;
	
	// Vergleichsberechnuung mit Skalarwerten
	start = clock();
	for(NSUInteger it = 0; it<iterations; it++)
	{
		skalarVierdimensional(daten, ergebnisseSkalar, count);
	}
	end = clock();
	skalarResultTime = (double)( end - start ) / (double)CLOCKS_PER_SEC*(double)1000.;
	
}

- (void)doBenchmarkCL
{
	int err;
	clock_t start, end;
	size_t global;
	cl_mem input;
	cl_mem output;
	cl_kernel kernel; 
	
	////////////////////////
	// OpenCL Berechnung  //
	////////////////////////
	
	[self createOpenCLContext]; // OpenCL Kontext anlegen und Kernelsourcen laden und kompilieren

	// Die verwendete Kernelfunktion auswählen
	kernel = clCreateKernel(program, "vierdimensional", &err);
	if (!kernel || err != CL_SUCCESS)
	{
		printf("Error: Failed to create compute kernel!\n");
		exit(1);
	}
	
	// Ein- und Ausgabearrays im ***Geräte***-Speicher anlegen
	// Ein- und Ausgabearrays im ***Geräte***-Speicher anlegen
	if(useGPU)
	{
		input = clCreateBuffer(context,  CL_MEM_READ_ONLY,  sizeof(cl_float4) * count, NULL, NULL);
		output = clCreateBuffer(context, CL_MEM_WRITE_ONLY, sizeof(cl_float4) * count, NULL, NULL);
	}
	else
	{
		input = clCreateBuffer(context,  CL_MEM_READ_ONLY|CL_MEM_USE_HOST_PTR,  sizeof(cl_float4) * count, daten, NULL);
		output = clCreateBuffer(context, CL_MEM_WRITE_ONLY|CL_MEM_USE_HOST_PTR, sizeof(cl_float4) * count, ergebnisseCL, NULL);
	}
	if (!input || !output)
	{
		printf("Error: Failed to allocate device memory!\n");
		exit(1);
	}    

	// Start der Zeitmessung
	start = clock();
	
	
	// Die Quelldaten in den ***Geräte***-Speicher schreiben. Dies ist ein Flaschenhals bei Verwendung der GPU!
	err = clEnqueueWriteBuffer(commands, input, CL_FALSE, 0, sizeof(cl_float4) * count, daten, 0, NULL, NULL);
	if (err != CL_SUCCESS)
	{
		printf("Error: Failed to write to source array!\n");
		exit(1);
	}
	
	// Argumente für den Kernel setzen
	err = 0;
	err  = clSetKernelArg(kernel, 0, sizeof(cl_mem), &input);
	err |= clSetKernelArg(kernel, 1, sizeof(cl_mem), &output);
	if (err != CL_SUCCESS)
	{
		printf("Error: Failed to set kernel arguments! %d\n", err);
		exit(1);
	}
		
	for(NSUInteger it = 0; it<iterations; it++)
	{
		// Kernelbearbeitung in die Queue stellen
		global = count;
		err = clEnqueueNDRangeKernel(commands, kernel, 1, NULL, &global, NULL, 0, NULL, NULL);
		if (err)
		{
			printf("Error: Failed to execute kernel!\n");
			exit(1);
		}
		
		// Queue bearbeiten!
		clFinish(commands);		
	}
	
	if(useGPU)
	{
		// Ergebniss aus dem  ***Geräte***-Speicher lesen. Dies ist ein Flaschenhals bei Verwendung der GPU!
		err = clEnqueueReadBuffer( commands, output, CL_TRUE, 0, sizeof(cl_float4) * count, ergebnisseCL, 0, NULL, NULL );  
		if (err != CL_SUCCESS)
		{
			printf("Error: Failed to read output array! %d\n", err);
			exit(1);
		}
	}
	
	end = clock();
	openCLResultTime = (double)( end - start ) / (double)CLOCKS_PER_SEC*(double)1000.;
	
	clReleaseKernel(kernel);
	clReleaseMemObject(input);
	clReleaseMemObject(output);
	
	[self destroyOpenCLContext];

}
@end
