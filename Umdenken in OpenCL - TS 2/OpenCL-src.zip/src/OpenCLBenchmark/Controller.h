#//
//  Controller.h
//  OpenCLBenchmark
//
//  Created by Eberhard Rensch on 27.09.10.
//  Copyright 2010 Pleasant Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface Controller : NSObject {
	NSWindow* window;
	
	BOOL  useGPU;
	NSUInteger datasize;
	BOOL multiDimensional;
	NSUInteger iterationsMultiplier;
	
	double longerTime;
	double openCLResultTime;
	double skalarResultTime;
	double faktor;

	BOOL calculatingCL;
	BOOL calculatingSkalar;
}

@property (retain) IBOutlet NSWindow* window;
@property (assign) BOOL  useGPU;
@property (assign) double faktor;
@property (assign) NSUInteger datasize;
@property (assign) BOOL multiDimensional;
@property (assign) NSUInteger iterationsMultiplier;
@property (assign) double openCLResultTime;
@property (assign) double skalarResultTime;
@property (assign) double longerTime;
@property (assign) BOOL calculatingCL;
@property (assign) BOOL calculatingSkalar;
@property (readonly) NSUInteger iterations;
@property (readonly) NSUInteger totalElements;
@property (readonly) NSUInteger totalBytes;

- (IBAction)doBenchmark:(id)sender;
@end
