//
//  Controller.m
//  OpenCLBenchmark
//
//  Created by Eberhard Rensch on 27.09.10.
//  Copyright 2010 Pleasant Software. All rights reserved.
//

#import "Controller.h"
#import "Benchmark.h"
#import "BenchmarkEindimensional.h"
#import "BenchmarkVierdimensional.h"
#import <OpenCL/OpenCL.h>

@implementation Controller
@synthesize useGPU, datasize, multiDimensional, iterationsMultiplier, openCLResultTime, skalarResultTime, longerTime, calculatingCL, calculatingSkalar, faktor, window;
@dynamic totalElements, iterations, totalBytes;


/////////////////////////////////////////
// Compilefehlertest
/////////////////////////////////////////
//- (id) init
//{
//	self = [super init];
//	if (self != nil) {
//		[self doBenchmark:nil];
//	}
//	return self;
//}

- (void) awakeFromNib
{
	
	self.useGPU=NO;
	self.datasize=128;
	self.multiDimensional = NO;
	self.iterationsMultiplier = 0;
	
	self.longerTime=1.;
	self.openCLResultTime=0.;
	self.skalarResultTime=0.;
	self.faktor=0.;
	
	NSLog(@"Verfügbare Geräte:");
	cl_device_id devices[10];
	cl_uint numDevices;
	clGetDeviceIDs(NULL, CL_DEVICE_TYPE_ALL, 10, devices, &numDevices);
	for(NSInteger i = 0; i<numDevices; i++)
	{
		cl_device_type type;
		clGetDeviceInfo(devices[i], CL_DEVICE_TYPE, sizeof(cl_device_type), &type, NULL);
		char name[256];
		size_t len;
		clGetDeviceInfo(devices[i], CL_DEVICE_NAME, 256, name, &len);
		cl_ulong mem;
		clGetDeviceInfo(devices[i], CL_DEVICE_GLOBAL_MEM_SIZE, sizeof(cl_ulong), &mem, NULL);
		
		NSLog(@"%s (%@): %d MB", name, (type==CL_DEVICE_TYPE_CPU)?@"CPU":(type==CL_DEVICE_TYPE_GPU)?@"GPU":[NSString stringWithFormat:@"%d",(int)type], (int)(mem/1024/1024));
	}
}

- (void) dealloc
{
	[window release];
	[super dealloc];
}

- (IBAction)doBenchmark:(id)sender
{
	[window makeFirstResponder:nil];
	self.calculatingCL = YES;
	self.skalarResultTime = 0.;
	self.openCLResultTime = 0.;
	self.faktor = 0.;
	self.longerTime=0;
	
	Benchmark* benchmark;
	if(multiDimensional)
	{
		benchmark = [[BenchmarkVierdimensional alloc] initWithDatasize:datasize*1024];
	}
	else
		benchmark = [[BenchmarkEindimensional alloc] initWithDatasize:datasize*1024];
	benchmark.useGPU = useGPU;
	benchmark.iterations = self.iterations;
	
	dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
		[benchmark doBenchmarkCL];
		dispatch_async(dispatch_get_main_queue(), ^{			
			self.longerTime=self.openCLResultTime=benchmark.openCLResultTime;
			self.calculatingCL = NO;
			self.calculatingSkalar = YES;
			NSBeep();
		});
		
		[benchmark doBenchmarkSkalar];
			
		dispatch_async(dispatch_get_main_queue(), ^{			
			self.longerTime=MAX(benchmark.skalarResultTime, benchmark.openCLResultTime);
			self.skalarResultTime=benchmark.skalarResultTime;
			self.calculatingSkalar= NO;
			self.faktor=self.skalarResultTime/self.openCLResultTime;
			NSBeep();
		});
		
		[benchmark release];
	});
}


- (NSUInteger)iterations
{
	switch(iterationsMultiplier)
	{
		case 1: return 50;
		case 2: return 100;
		case 3: return 200;
		case 4: return 300;
		case 5: return 400;
		case 6: return 500;
		case 7: return 600;
		case 8: return 800;
		case 9: return 1000;
		case 10: return 2000;
		default: return 1;
	}
}

- (NSUInteger)totalElements
{
	return datasize*1024*self.iterations;
}

- (NSUInteger)totalBytes
{
	size_t eSize;
	if(multiDimensional)
		eSize = sizeof(cl_float4);
	else
		eSize = sizeof(cl_float);
		
	return  datasize*eSize;
}


+ (NSSet *)keyPathsForValuesAffectingTotalElements
{
	return [NSSet setWithObjects:@"iterationsMultiplier", @"datasize", nil];
}

+ (NSSet *)keyPathsForValuesAffectingTotalBytes
{
	return [NSSet setWithObjects:@"multiDimensional", @"datasize", nil];
}

+ (NSSet *)keyPathsForValuesAffectingIterations
{
	return [NSSet setWithObjects:@"iterationsMultiplier", nil];
}

@end
