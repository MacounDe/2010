//
//  OpenCLBenchmarkAppDelegate.h
//  OpenCLBenchmark
//
//  Created by Eberhard Rensch on 27.09.10.
//  Copyright 2010 Pleasant Software. All rights reserved.
//

#import <Cocoa/Cocoa.h>

@interface OpenCLBenchmarkAppDelegate : NSObject <NSApplicationDelegate> {
    NSWindow *window;
}

@property (assign) IBOutlet NSWindow *window;

@end
