//
//  OpenCLBenchmarkAppDelegate.m
//  OpenCLBenchmark
//
//  Created by Eberhard Rensch on 27.09.10.
//  Copyright 2010 Pleasant Software. All rights reserved.
//

#import "OpenCLBenchmarkAppDelegate.h"

@implementation OpenCLBenchmarkAppDelegate

@synthesize window;

- (void)applicationDidFinishLaunching:(NSNotification *)aNotification {
	// Insert code here to initialize your application 
}

@end
