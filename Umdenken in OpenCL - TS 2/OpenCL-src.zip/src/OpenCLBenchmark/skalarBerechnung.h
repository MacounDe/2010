/*
 *  skalarBerechnung.h
 *  OpenCLBenchmark
 *
 *  Created by Eberhard Rensch on 27.09.10.
 *  Copyright 2010 Pleasant Software. All rights reserved.
 *
 */

#import <OpenCL/OpenCL.h>

void skalarEindimensional(float* input, float* output, const unsigned int count);
void skalarVierdimensional(cl_float4* input, cl_float4* output, const unsigned int count);
