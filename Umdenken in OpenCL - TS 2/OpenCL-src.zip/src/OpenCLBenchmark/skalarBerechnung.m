/*
 *  skalarBerechnung.c
 *  OpenCLBenchmark
 *
 *  Created by Eberhard Rensch on 27.09.10.
 *  Copyright 2010 Pleasant Software. All rights reserved.
 *
 */

#import "skalarBerechnung.h"
#import <math.h>
void skalarEindimensional(float* input, float* output, const unsigned int count)
{
	unsigned int i;
	for(i=0; i<count; i++)
		output[i] = sqrtf(input[i] * input[i]);
}



void skalarVierdimensional(cl_float4* input, cl_float4* output, const unsigned int count)
{
	unsigned int i, d;
	for(i=0; i<count; i++)
	{
		float len = sqrtf(input[i][0] * input[i][0] + input[i][1] * input[i][1] + input[i][2] * input[i][2] + input[i][3] * input[i][3]);
		if(len==0)
			for(d=0; d<4; d++)
				output[i][d] = 0.f;
		else
			for(d=0; d<4; d++)
				output[i][d] = input[i][d]/len;
	}			
}
