#include <CoreFoundation/CoreFoundation.h>
#include <OpenCL/OpenCL.h>

int main (int argc, const char * argv[]) {
 	printf("Verfügbare Geräte:\n");
	
	
	cl_device_id devices[10];
	cl_uint numDevices;
	
	if(CL_SUCCESS == clGetDeviceIDs(NULL, CL_DEVICE_TYPE_ALL, 10, devices, &numDevices))
	{
		for(int i = 0; i<numDevices; i++)
		{
			cl_device_type type;
			clGetDeviceInfo(devices[i], CL_DEVICE_TYPE, sizeof(cl_device_type), &type, NULL);
			
			char name[256];
			size_t len;
			clGetDeviceInfo(devices[i], CL_DEVICE_NAME, 256, name, &len);
			
			cl_ulong mem;
			clGetDeviceInfo(devices[i], CL_DEVICE_GLOBAL_MEM_SIZE, sizeof(cl_ulong), &mem, NULL);
			
			printf("%s (%s): %d MB globaler Speicher\n", name, (type==CL_DEVICE_TYPE_CPU)?"CPU":"GPU", (int)(mem/1024/1024));
		}
	}
   return 0;
}
