Zum Kompilieren wird eine zur Entwicklung vorbereitete Version von Pleasant3D auf dem Rechner ben�tigt.

Pleasant3D ist kostenlos hier downloadbar:
http://www.pleasantsoftware.com/developer/pleasant3d/index.shtml

Die Installation der Pleasant3D Entwicklungsumgebung ist hier downloadbar:
http://download.pleasantsoftware.com/pleasant3d/InstallDevSupport.zip

Eine Anleitung (auf englisch) ist hier zu finden:
http://pleasantsoftware.com/developer/3d/2010/03/01/pleasant-future/

----

To install a tool plugin copy the bundle into
~/Library/Application Support/Pleasant3D/PlugIns

To debug a plugin from within XCode, create a new custom executable. Set the Executable Path to Pleasant3D.app.
Then add the following Argument to the executable:
-i$(SRCROOT)/$(BUILD_DIR)/$(CONFIGURATION)

This will cause Pleasant3D to scan and load also plugins directly from your plugin build directory.